export default function Footer(){
    return(<>
        <footer style={{backgroundColor:"black",textAlign:"center",color:"white", padding:"5px",marginTop:"20px"}}>Copyrights reserved</footer>
    </>)
}