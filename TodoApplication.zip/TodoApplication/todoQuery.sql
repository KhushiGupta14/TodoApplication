Create Database todo;

use todo;